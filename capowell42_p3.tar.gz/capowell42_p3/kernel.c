//write c code in here, given as psudo code in assignment 
#include <limits.h>
#include <stdint.h>
#include <stddef.h>

void k_printstr(char *string, int r, int c);

void run_test();
void timer_isr();
void lidtr();
void initialize_timer(int ms);
void k_writeport(uint16_t port, uint8_t value);
extern void timer_handler();

void *kmalloc(uint32_t size);
void buddy_init();
int convert_num(unsigned int num, char buf[]);

extern void yield(uint32_t new_esp);

void restore_context(uint32_t t);
void dispatch();
void dispatch_leave();

void print_border(int start_row,int start_col, int width, int height){
    k_printstr("\xC9", start_row, start_col); // top left // prints the corners for the border 
    k_printstr("\xBB", start_row, start_col + height); // top right
    k_printstr("\xC8", start_row + width, start_col); // bottom left
    k_printstr("\xBC", start_row + width, start_col + height); // bottom right

    for (int s = start_col + 1; s < height; s++ ){ //prints the sides for the border 
        k_printstr("\xCD", start_row, s);
        k_printstr("\xCD", start_row + width, s);
    }

    for (int i = start_row + 1; i < width; i++){ // prints the top and bottom of the border 
        k_printstr("\xBA", i, start_col);
        k_printstr("\xBA", i, start_col + height);
    }
}

void k_clearscr(int start_row, int start_col, int width, int height){
    for (int r = start_row; r <= width; r++ ){
        for (int c = start_col; c <= height; c++ ){
            // k_printstr(" ", start_row, c);
            k_printstr(" ", r, c);
        }
    }

}

void timer_handler(){
    static int what = 0;
    /*if what is 0 then
        print a star ("*") in the middle of the screen
    else 
        print a space (" ") in the middle of the screen
    end if 
    set what to not what */

    if (what==0){
        k_printstr("*",12,40);
    }
    else {
        k_printstr(" ",12,40);
    }
    what = !what;
}


void setup_PIC() {
 // set up cascading mode:
 k_writeport(0x20, 0x11); // start 8259 master initialization
 k_writeport(0xA0, 0x11); // start 8259 slave initialization
 k_writeport(0x21, 0x20); // set master base interrupt vector (idt 32-38)
 k_writeport(0xA1, 0x28); // set slave base interrupt vector (idt 39-45)
 // Tell the master that he has a slave:
 k_writeport(0x21, 0x04); // set cascade ...
 k_writeport(0xA1, 0x02); // on IRQ2
 // Enabled 8086 mode:
 k_writeport(0x21, 0x01); // finish 8259 initialization
 k_writeport(0xA1, 0x01);
 // Reset the IRQ masks
 k_writeport(0x21, 0x0);
 k_writeport(0xA1, 0x0);
 // Now, enable the clock IRQ only 
 k_writeport(0x21, 0xfe); // Turn on the clock IRQ
 k_writeport(0xA1, 0xff); // Turn off all others
}

void default_handler(){

    k_printstr("ERROR",0,1);
    int t = 1;
    while (t==1) {

    }

}


struct idt_entry{
    uint16_t base_low;
    uint16_t selector;
    uint8_t always0;
    uint8_t access;
    uint16_t base_hi;
} __attribute__((packed));

struct idtr{
    uint16_t limit;
    uint32_t base;
}__attribute__((packed));

typedef struct idt_entry idt_entry_t;
typedef struct idtr idtr_t;
idtr_t idtr;
idt_entry_t idt[256];

void init_idt_entry(idt_entry_t *entry, uint32_t addr_of_handler, uint16_t code_selector, uint8_t access){
    entry->base_low=addr_of_handler;
    entry->selector=code_selector;
    entry->always0=0;
    entry->access=access;
    entry->base_hi=addr_of_handler>>16;
}




void init_idt(){
    //call init_idt_entry() for entries 0-31 setting these to the default handlers (code_selector is 16)

    for (int i=0; i <= 31; i++){
        init_idt_entry(idt+i,default_handler,16,0x8e); //might be very wrong 
    }
    init_idt_entry(idt+32,dispatch,16,0x8e); //swapped timer_isr for dispatch
    //call init_idt_entry() for entry 32 to point to timer isr function (code_slector is 16)

    for (int a=33; a<=255; a++){
        init_idt_entry(idt+a,0,0,0); 
    }
    //call init_idt_entry() for entries 33-255 setting them to 0. pass all parameters of init_idt_entry as 0

    idtr.limit=sizeof idt-1;
    idtr.base=idt;
    //Declare a variable called idtr, and fill in its structure with the limit and base of the idt array 
    //(The limit is the size of idt in bytes minus 1)
    lidtr(&idtr);
    //call lidtr(&idtr);

}
//------------------------------------------New for Assignment 3--------------------------------------------------------


int pid = 1;

struct pcb {
    uint32_t esp;
    uint32_t pid;
}__attribute__((packed));
typedef struct pcb pcb_t;


struct ST_PROTO {
        uint32_t gen_regs[8];
        uint32_t dispatcher_exit;
        uint32_t EIP;
        uint32_t CS;
        uint32_t EFLAGS;
} __attribute__((packed));
typedef struct ST_PROTO ST_PROTO_t;

typedef struct queueNode queueNode_t;
struct queueNode {
    pcb_t *data;
    queueNode_t* next;

}__attribute__((packed));

typedef struct pcbq pcbq_t;
struct pcbq {
    queueNode_t *front, *rear;
    
}__attribute__((packed));

void enqueue(pcbq_t *q, pcb_t *p)
    {
 
        // Create a new LL node
        queueNode_t* temp = (queueNode_t*) kmalloc(sizeof(queueNode_t));

        

        temp->data = p;
    
 
        // If queue is empty, then
        // new node is front and rear both
        if (q->rear == NULL) {
            q->front = q->rear = temp;
            return;
        }
 
        // Add the new node at
        // the end of queue and change rear
        q->rear->next = temp;
        q->rear = temp;
    }
 
    // Function to remove
    // a key from given queue q
    pcbq_t *dequeue(pcbq_t *q)
    {
        // If queue is empty, return NULL.
        if (q->front == NULL)
            return;
        queueNode_t* nodeToDelete = q->front;

        pcb_t* x = nodeToDelete->data;

        if (q->front == q->rear) {
          q->front = q->rear = NULL;
        }
        else {
         q->front = q->front->next;
        }
        return x;
    }




pcbq_t *create_queue(){
    pcbq_t* q = (pcbq_t*)kmalloc(sizeof(pcbq_t));
    q->front = NULL;
    q->rear = NULL;
    return q;
}

pcb_t *running;
pcbq_t *globalQueue;

int create_process(uint32_t code_address) {
    // code_address is the pointer to the function that contains the process code

      
        //set stackptr to return value of calling kmalloc() to allocate a stack
        //      that is 1024 integers in size
        //check to make sure stackptr is not null

        uint32_t stackptr = (uint32_t*)kmalloc(1024 * 4);

        if (stackptr == NULL){return 1;}
       
            // First, set up the stack

        //set st to stackptr + the size of a uint32_t * 1024 to put st at the
        //     bottom of the stack
        //set st to st - the size of the template context ST_PROTO to
        //      leave room for the new context
        //declare variable ctx on type pointer to ST_PROTO and set it to st
            // create context that will set gen purpose regs to 0
        int st = stackptr + (sizeof(uint32_t) * 1024);
        st = st - sizeof(ST_PROTO_t);

        ST_PROTO_t *ctx = st;

        //loop i from 0 to 8
        //    set ctx pointing to gen_regs[i] to zero

        for (int i = 0; i < 8; i++){
            ctx->gen_regs[i] = 0;
        }
        //set ctx pointing to dispatcher_exit to dispatch_leave
        ctx->dispatcher_exit = dispatch_leave;
        //set ctx pointing to EIP to code_address
        ctx->EIP = code_address;
        //set ctx pointing to CS to 16 // the selector for the code segment
        ctx->CS = 16;
        //set ctx pointing to EFLAGS to 0x200  // this will enable interrupts
        ctx->EFLAGS = 0x200;
            // Note: you will have to create the pcb struct for the following code
        //set pcb to the return value of calling kmalloc to allcate a pcb struct
        //set the pcb's esp member to st.
        //set the pcb's pid member to next pid  //Note that you can keep track
                                              // of the next pid using a
                                              // global variable
        pcb_t *pcb = (pcb_t*)kmalloc(sizeof(pcb_t));
        pcb->esp = st;
        pcb->pid = pid;
        pid = pid + 1;

        //enqueue the pcb onto the ready queue  // ready queue will be a global
        

        enqueue(globalQueue, pcb);

        return 0; /* no errors occured */
        // Note that if kmalloc ever returns NULL, you should return a
        //  non-zero value instead to indicate the error
    }



void go() {
	/* Note: you should have a global variable to keep
	   track of the current running process (call
	   it "Running"). It should be a pointer to a
	   pcb structure. */
	//dequeue pcb from the ready queue and make it the current running process
	//call restore_context()
    running = dequeue(globalQueue);
    restore_context(running->esp);
}

void p1(){
    //begin
      //print a border from row 10, column 10 to row 13, column 35.
    print_border(10,10,3,25);
      //k_printstr the message "Process 1 running..." at row 11 column 11.
    k_printstr("Process 1 running...",11,11);
      //set num to 0
    int num = 0;
      //k_printstr "value: " at row 12, column 11
    k_printstr("value: ",12,11);
      //loop forever
    char strNum[4];
    while(1){
         //convert num to a string using convert_num()
        convert_num(num, strNum);
        //k_printstr the string number at row 12, column 18
        k_printstr(strNum,12,18);
        //add one to num
        num ++;
        //if num is greater than 1000, set num to zero
        if (num >= 1000){
            num = 0;
        }
      //end loop
    }
    //end
}

     
void p2(){
    //begin
         // The same for p1, but print "Process 2 running..."
         // and the border should be from row 15, column 10
         //    to row 18, column 35
         // Print the values inside that box.
   // end

       //begin
      //print a border from row 10, column 10 to row 13, column 35.
    print_border(15,10,3,25);
      //k_printstr the message "Process 1 running..." at row 11 column 11.
    k_printstr("Process 2 running...",16,11);
      //set num to 0
    int num = 0;
      //k_printstr "value: " at row 12, column 11
    k_printstr("value: ",17,11);
      //loop forever
    char strNum[4];
    while(1){
         //convert num to a string using convert_num()
        convert_num(num, strNum);
        
        //k_printstr the string number at row 12, column 18
        k_printstr(strNum,17,18);
        //add one to num
        num ++;
        //if num is greater than 1000, set num to zero
        if (num >= 1000){
            num = 0;
        }
      //end loop
    }
    //end
}

void yield(uint32_t new_esp) {
	//set the esp at which Running points to new_esp
	//enqueue Running to the round robin queue

	//dequeue the next PCB from the round robin queue
		//and make Running point to it
	//call restore_context()
    
    running->esp = new_esp;
    enqueue(globalQueue, running);
    running = dequeue(globalQueue);
    restore_context(running->esp);

}



void main(){

   // function to clear the screen
    k_clearscr(0,0,24,79);
    
    //function to print the border
    print_border(0,0,24,79);
    

    buddy_init();

    init_idt();

    //initialize RR queue data structures 
    globalQueue = create_queue();

    initialize_timer(50);

    setup_PIC();

    

    //set retval to the return value of create_process(p1)
    int retval = create_process(p1);


    //check if error (retval != 0)
    while (retval != 0 ){}

   retval = create_process(p2);


    //check if error (retval != 0)
    while (retval != 0 ){}

    go();

    //asm("sti");     // NOTE: REMOVE THE asm("sti")!

    //go()

   // int t = 1;
    //while (t==1){

   // }

    /*
    int main() {

    clear the screen
    print "Running processes" on the first line of the screen

    initialize the IDT
→   initialize RR queue data structures  
         
    initialize the timer device (50 ms)
    set up the PIC
→   set retval to the return value of create_process(p1)
→   check if error (retval != 0)
    // repeat the above for process p2
    // NOTE: REMOVE THE asm("sti")!
    // Now begin running the first process ...
→   go()
    // go never returns to main
}
    */
}
