void k_print(char *s, int len, int row, int col);
void k_printstr(char *s, int row, int col);