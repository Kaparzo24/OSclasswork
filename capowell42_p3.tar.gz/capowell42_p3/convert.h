int convert_num(unsigned int num, char buf[]);
